1:parseJson.py里修改类别。
2:json2voc.py更改相应路径。

