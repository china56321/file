1.运行csv_2_one_txt.py ,该脚本将CSV文件里的内容保存为TXT格式文件。（可运行del.py删除不需要的节点。——
2.运行csv_2_single_txt.py ,该脚本将合并一张图片的数据，并生成一个txt文件。
3.运行txt2xml.py，该脚本将生成对应的XML文件。


