# -*- coding:utf-8 -*-
#!/usr/bin/python
with open("name.txt",'r') as f:
   a=f.readlines()  
   for i in a:
      # print(i.split(" ")[1])
      # print(i)  # first row
      k=i.split(" ")[0].strip()
      # print(k)                    #first one 
      j=str(k.split(".")[0])
      # print(j)                      # just name
      name=open(j+'.txt','a')
      if i.split(" ")[0]==k:
        name.write((str(i.split(" ")[1])+' '+str(i.split(" ")[2])+' '+str(i.split(" ")[3])+' '+str(i.split(" ")[4])+' '+str(i.split(" ")[5])))
        # print(i)










