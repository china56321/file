with open('udacity.txt','r') as f:
   a=f.readlines()  
   for i in a:
     k=i.split(" ")[1].strip()
     print(k)
     if k  in ["person","car","truck","biker"] :
        with open("name.txt",'a') as b:
           b.write(i)

          