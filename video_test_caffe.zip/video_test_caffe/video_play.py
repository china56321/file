#-*- coding: utf-8 -*-
# import cv2
# import threading
 
 
# class Producer(threading.Thread):
# #     """docstring for ClassName"""  
#     def __init__(self,str_rtsp):
#         super(Producer, self).__init__()
#         self.str_rtsp = str_rtsp
#         #通过cv2中的类获取视频流操作对象cap  
#         self.cap = cv2.VideoCapture(self.str_rtsp)
#         #调用cv2方法获取cap的视频帧（帧：每秒多少张图片
#         fps = self.cap.get(cv2.CAP_PROP_FPS)
#         print(fps)
#         #获取cap视频流的每帧大小  
#         size = (int(self.cap.get(cv2.CAP_PROP_FRAME_WIDTH)),
#             int(self.cap.get(cv2.CAP_PROP_FRAME_HEIGHT)))
#         print(size)
#         #定义编码格式mpge-4  
#         fourcc = cv2.VideoWriter_fourcc('M', 'P', '4', '2')
#         #定义视频文件输入对象  
#         # self.outVideo = cv2.VideoWriter('saveDir.avi',fourcc,fps,size)
#         cv2.namedWindow("cap video",0)
#     def run(self):
#         print('in producer')
#         while True:
#             ret,image = self.cap.read()
#             if (ret == True):
#                 cv2.imshow('cap video',image)
#                 # self.outVideo.write(image)
#             if cv2.waitKey(1) & 0xFF == ord('q'):
#                 # self.outVideo.release()
#                 self.cap.release()
#                 cv2.destroyAllWindows()
#                 break
#                 # continue

# if __name__ == '__main__':
#     print('run program')
#     rtsp_str='D:\\Media\\05_AdasOut\\20171218\\20171218_161015.ts'
#     producer = Producer(rtsp_str)
#     producer.start()


import numpy as np
import cv2

cap = cv2.VideoCapture('1.MP4')
wid = int(cap.get(3))
hei = int(cap.get(4))
framerate = int(cap.get(5))
framenum = int(cap.get(7))
 
# video = np.zeros((framenum,hei,wid,3),dtype='float16')
cnt = 0
while(cap.isOpened()):
    a,b=cap.read()
    cv2.imshow('player', b)
    cv2.waitKey(20)
    b = b.astype('float16')/255
    cnt = cnt+1
    print(cnt)
