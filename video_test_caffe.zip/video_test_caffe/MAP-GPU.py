import numpy as np  
import sys,os  
import cv2
import pickle
import matplotlib.pyplot as plt
import pylab as pl
from sklearn.metrics import precision_recall_curve
from itertools import cycle
import logging
import xml.etree.ElementTree as ET
import matplotlib
caffe_root = '/home/ubuntu/caffe-ssd/'
sys.path.insert(0, caffe_root + 'python')  
import caffe  

logger = logging.getLogger(__name__)



net_file= 'ssdlite/coco/deploy.prototxt'
caffe_model='ssdlite/deploy.caffemodel'  
test_dir = "/home/ubuntu/caffe-ssd/data/VOCdevkit/MyDataSet/testJPEGImages"
detpath="/home/ubuntu/caffe-ssd/data/VOCdevkit/MyDataSet/Dections"
caffe.set_mode_gpu()
caffe.set_device(0)

#caffe.set_mode_cpu()
net = caffe.Net(net_file,caffe_model,caffe.TEST)  

COCO_CLASSES = ("background" , "person" , "bicycle" , "car" , "motorcycle" , 
     "airplane" , "bus" , "train" , "truck" , "boat" , "traffic light",
     "fire hydrant", "N/A" , "stop sign", "parking meter", "bench" , 
     "bird" , "cat" , "dog" , "horse" , "sheep" , "cow" , "elephant" , 
     "bear" , "zebra" , "giraffe" , "N/A" , "backpack" , "umbrella" , 
     "N/A" , "N/A" , "handbag" , "tie" , "suitcase" , "frisbee" , "skis" ,
     "snowboard" , "sports ball", "kite" , "baseball bat", "baseball glove",
     "skateboard" , "surfboard" , "tennis racket", "bottle" , "N/A" ,
     "wine glass", "cup" , "fork" , "knife" , "spoon" , "bowl" , "banana" ,
     "apple" , "sandwich" , "orange" , "broccoli" , "carrot" , "hot dog",
     "pizza" , "donut" , "cake" , "chair" , "couch" , "potted plant", 
     "bed" , "N/A" , "dining table", "N/A" , "N/A" , "toilet" , "N/A" ,
     "tv" , "laptop" , "mouse" , "remote" , "keyboard" , "cell phone",
     "microwave" , "oven" , "toaster" , "sink" , "refrigerator" , "N/A" ,
     "book" , "clock" , "vase" , "scissors" , "teddy bear", "hair drier",
     "toothbrush" )

def preprocess(src):
    img = cv2.resize(src, (300,300))
    img = img - 127.5
    img = img / 127.5
    return img

def postprocess(img, out):   
    h = img.shape[0]
    w = img.shape[1]
    box = out['detection_out'][0,0,:,3:7] * np.array([w, h, w, h])

    cls = out['detection_out'][0,0,:,1]
    conf = out['detection_out'][0,0,:,2]
    return (box.astype(np.int32), conf, cls)

def detect(list_detect,imgfile):
    origimg = cv2.imread(imgfile)
    img = preprocess(origimg)
    
    img = img.astype(np.float32)
    img = img.transpose((2, 0, 1))

    net.blobs['data'].data[...] = img
    out = net.forward() 
    box, conf, cls = postprocess(origimg, out)

    for i in range(len(box)):
       p1 = (box[i][0], box[i][1])
       p2 = (box[i][2], box[i][3])
       print (os.path.split(imgfile)[1],conf[i],box[i][0],box[i][1],box[i][2],box[i][3])
       if COCO_CLASSES[int(cls[i])]=="person":
          list_detect.append([os.path.split(imgfile)[1]," ",str(conf[i])," ",str(box[i][0])," ",str(box[i][1])," ",str(box[i][2])," ",str(box[i][3])])
          #cv2.rectangle(origimg, p1, p2, (0,255,0))
          #p3 = (max(p1[0], 15), max(p1[1], 15))
          title = "%s:%.2f" % (COCO_CLASSES[int(cls[i])], conf[i])
          print (title)
          #cv2.putText(origimg, title, p3, cv2.FONT_ITALIC, 0.6, (0, 255, 0), 1)
    #cv2.imshow("SSD", origimg)
 
    #k = cv2.waitKey(0) & 0xff
        #Exit if ESC pressed
    #if k == 27 : return False
    return True
list_detect=[]
for f in os.listdir(test_dir):
    if f.endswith(".jpg") and detect(list_detect,test_dir + "/" + f) == False:
       break
#print list_detect

with open(detpath+"/"+"detect.txt", "w") as fp:
    for line in list_detect:
        fp.writelines(line)
        fp.write('\n')

def parse_rec(filename):
    """Parse a PASCAL VOC xml file."""
   
    tree = ET.parse(filename)
    objects = []
    for obj in tree.findall('object'):
        obj_struct = {}
        obj_struct['name'] = obj.find('name').text
        obj_struct['pose'] = obj.find('pose').text
        obj_struct['truncated'] = int(obj.find('truncated').text)
        obj_struct['difficult'] = int(obj.find('difficult').text)
        bbox = obj.find('bndbox')
        obj_struct['bbox'] = [int(bbox.find('xmin').text),
                              int(bbox.find('ymin').text),
                              int(bbox.find('xmax').text),
                              int(bbox.find('ymax').text)]
        objects.append(obj_struct)

    return objects


def voc_ap(rec, prec, use_07_metric=False):
    """Compute VOC AP given precision and recall. If use_07_metric is true, uses
    the VOC 07 11-point method (default:False).
    """
    if use_07_metric:
        # 11 point metric
        ap = 0.
        for t in np.arange(0., 1.1, 0.1):
            if np.sum(rec >= t) == 0:
                p = 0
            else:
                p = np.max(prec[rec >= t])
            ap = ap + p / 11.
    else:
        # correct AP calculation
        # first append sentinel values at the end
        mrec = np.concatenate(([0.], rec, [1.]))
        mpre = np.concatenate(([0.], prec, [0.]))

        # compute the precision envelope
        for i in range(mpre.size - 1, 0, -1):
            mpre[i - 1] = np.maximum(mpre[i - 1], mpre[i])

        # to calculate area under PR curve, look for points
        # where X axis (recall) changes value
        i = np.where(mrec[1:] != mrec[:-1])[0]

        # and sum (\Delta recall) * prec
        ap = np.sum((mrec[i + 1] - mrec[i]) * mpre[i + 1])
    return ap


def voc_eval(detpath,
             annopath,
             imagesetfile,
             classname,
             cachedir,
             ovthresh=0.5,
             use_07_metric=False):
    """rec, prec, ap = voc_eval(detpath,
                                annopath,
                                imagesetfile,
                                classname,
                                [ovthresh],
                                [use_07_metric])
    Top level function that does the PASCAL VOC evaluation.
    detpath: Path to detections
        detpath.format(classname) should produce the detection results file.
    annopath: Path to annotations
        annopath.format(imagename) should be the xml annotations file.
    imagesetfile: Text file containing the list of images, one image per line.
    classname: Category name (duh)
    cachedir: Directory for caching the annotations
    [ovthresh]: Overlap threshold (default = 0.5)
    [use_07_metric]: Whether to use VOC07's 11 point AP computation
        (default False)
    """
    # assumes detections are in detpath.format(classname)
    # assumes annotations are in annopath.format(imagename)
    # assumes imagesetfile is a text file with each line an image name
    # cachedir caches the annotations in a pickle file

    # first load gt
    if not os.path.isdir(cachedir):
        os.mkdir(cachedir)
    imageset = os.path.splitext(os.path.basename(imagesetfile))[0]
    if os.path.isfile(os.path.join(cachedir, imageset + '_annots.pkl')):
       os.remove(os.path.join(cachedir, imageset + '_annots.pkl'))
    cachefile = os.path.join(cachedir, imageset + '_annots.pkl')
    # read list of images
    with open(imagesetfile, 'r') as f:
        lines = f.readlines()
    imagenames = [x.strip() for x in lines]

    if not os.path.isfile(cachefile):
        # load annots
        recs = {}
        for i, imagename in enumerate(imagenames):
            recs[imagename] = parse_rec(annopath+"/"+os.path.splitext(imagename)[0]+".xml")
            if i % 100 == 0:
                logger.info(
                    'Reading annotation for {:d}/{:d}'.format(
                        i + 1, len(imagenames)))
        # save
        logger.info('Saving cached annotations to {:s}'.format(cachefile))
        with open(cachefile, 'wb') as f:
            pickle.dump(recs,f)
    else:
        # load
        with open(cachefile, 'rb') as f:
            recs = pickle.load(f)

    # extract gt objects for this class
    class_recs = {}
    npos = 0
    for imagename in imagenames:
        #print (imagename,recs[imagename])
        R = [obj for obj in recs[imagename] if obj['name'] == classname]
        bbox = np.array([x['bbox'] for x in R])
        difficult = np.array([x['difficult'] for x in R]).astype(np.bool)
        det = [False] * len(R)
        npos = npos + sum(~difficult)
        class_recs[imagename] = {'bbox': bbox,
                                 'difficult': difficult,
                                 'det': det}

    # read dets
    detfile = detpath+"/"+"detect.txt"
    with open(detfile, 'r') as f:
        lines = f.readlines()
    #print (lines)
    splitlines = [x.strip().split(' ') for x in lines]
    image_ids = [x[0] for x in splitlines]
    confidence = np.array([float(x[1]) for x in splitlines])
    BB = np.array([[float(z) for z in x[2:]] for x in splitlines])

    # sort by confidence
    sorted_ind = np.argsort(-confidence)# sort ascend
    #print (sorted_ind)
    BB = BB[sorted_ind, :]
    image_ids = [image_ids[x] for x in sorted_ind]
    #print (image_ids)
    # go down dets and mark TPs and FPs
    nd = len(image_ids)
    tp = np.zeros(nd)
    fp = np.zeros(nd)
    for d in range(nd):
        
        R = class_recs[image_ids[d]]
        bb = BB[d, :].astype(float)
        ovmax = -np.inf
        BBGT = R['bbox'].astype(float)
        #print (image_ids[d],bb)
        if BBGT.size > 0:
            # compute overlaps
            # intersection
            ixmin = np.maximum(BBGT[:, 0], bb[0])
            iymin = np.maximum(BBGT[:, 1], bb[1])
            ixmax = np.minimum(BBGT[:, 2], bb[2])
            iymax = np.minimum(BBGT[:, 3], bb[3])
            iw = np.maximum(ixmax - ixmin + 1., 0.)
            ih = np.maximum(iymax - iymin + 1., 0.)
            inters = iw * ih

            # union
            uni = ((bb[2] - bb[0] + 1.) * (bb[3] - bb[1] + 1.) +
                   (BBGT[:, 2] - BBGT[:, 0] + 1.) *
                   (BBGT[:, 3] - BBGT[:, 1] + 1.) - inters)

            overlaps = inters / uni
            ovmax = np.max(overlaps)
            jmax = np.argmax(overlaps)

        if ovmax > ovthresh:
            if not R['difficult'][jmax]:
                if not R['det'][jmax]:
                    tp[d] = 1.
                    R['det'][jmax] = 1
                else:
                    fp[d] = 1.
        else:
            fp[d] = 1.

    # compute precision recall
    fp = np.cumsum(fp)
    tp = np.cumsum(tp)
    rec = tp / float(npos)
    # avoid divide by zero in case the first detection matches a difficult
    # ground truth
    prec = tp / np.maximum(tp + fp, np.finfo(np.float64).eps)
    ap = voc_ap(rec, prec, use_07_metric)
    print "Rec=",np.mean(rec)
    print "Prec=",np.mean(prec)
    print "Map=",ap
    plt.figure(1)  
    plt.title('Precision/Recall Curve')# give plot a title
    plt.xlabel('Recall')# make axis labels
    plt.ylabel('Precision')
    plt.plot(prec, rec)
    plt.show()
    plt.savefig('p-r.png')
 
    #return rec, prec, ap






detpath="/home/ubuntu/caffe-ssd/data/VOCdevkit/MyDataSet/Dections"
annopath="/home/ubuntu/caffe-ssd/data/VOCdevkit/MyDataSet/testJPEGImages"
image_path="/home/ubuntu/caffe-ssd/data/VOCdevkit/MyDataSet/testJPEGImages"
classname="person"
cachedir="/home/ubuntu/caffe-ssd/data/VOCdevkit/MyDataSet/PKL"
ovthresh=0.5
use_07_metric=False

image_list=[]
xml_list=[]
for list_name in os.listdir(image_path):
    if list_name.endswith(".jpg"):
        image_list.append(list_name)


with open(detpath+"/"+"image.txt", "w") as fp:
    for line in image_list:
        fp.writelines(line)
        fp.write('\n')




imagesetfile=detpath+"/"+"image.txt"


voc_eval(detpath,annopath,imagesetfile,classname,cachedir,ovthresh,use_07_metric)


