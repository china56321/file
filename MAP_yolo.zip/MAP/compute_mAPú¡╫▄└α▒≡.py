# rec,prec,ap = voc_eval('/home/zhb/make/darknet/results/{}.txt', '/home/zhb/make/darknet/scripts/Annotations/{}.xml', '/home/zhb/make/darknet/scripts/test.txt', 'cat', '.')

#第1项：表示检测结果文件路径 
#第2项：表示标签文件的路径 
#第3项：表示测试文件路径 
#第4项：类名

from voc_eval import voc_eval

import os

current_path = os.getcwd()
results_path = current_path+"/results"
sub_files = os.listdir(results_path)

mAP = []
for i in range(len(sub_files)):
    class_name = sub_files[i].split(".txt")[0]
    rec, prec, ap = voc_eval('/home/zhb/make/darknet/results/{}.txt', '/home/zhb/make/darknet/scripts/Annotations/{}.xml', '/home/zhb/make/darknet/scripts/test.txt', class_name, '.')
    print("{} :\t {} ".format(class_name, ap))
    mAP.append(ap)

mAP = tuple(mAP)

print("***************************")
print("mAP :\t {}".format( float( sum(mAP)/len(mAP)) )) 

