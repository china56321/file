from voc_eval import voc_eval

# rec,prec,ap = voc_eval('/home/zhb/make/darknet/results/{}.txt', '/home/zhb/make/darknet/scripts/VOCdevkit/VOC2007/Annotations/{}.xml', '/home/zhb/make/darknet/scripts/VOCdevkit/VOC2007/ImageSets/Main/test.txt', 'car', '.')

rec,prec,ap = voc_eval('/home/zhb/make/darknet/results/{}.txt', '/home/zhb/make/darknet/scripts/Annotations/{}.xml', '/home/zhb/make/darknet/scripts/test.txt', 'cat', '.')
#第1项：表示检测结果文件路径 
#第2项：表示标签文件的路径 
#第3项：表示测试文件路径 
#第4项：类名

print('rec:',rec)
print('prec:',prec)
print('ap:',ap)



