from voc_eval import voc_eval

rec,prec,ap = voc_eval('/home/zhb/make/darknet/results/{}.txt', '/home/zhb/make/darknet/scripts/VOCdevkit/VOC2007/Annotations/{}.xml', '/home/zhb/make/darknet/scripts/VOCdevkit/VOC2007/ImageSets/Main/test.txt', '1', '.')

print('rec',rec)
print('prec',prec)
print('ap',ap)

