mAP-Computing
